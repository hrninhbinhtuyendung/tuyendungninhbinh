﻿import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { isSupabaseConfigured, supabase, type JobRecord } from "../lib/supabase";
import "./Home.css";

type JobView = {
  id: number;
  title: string;
  company: string;
  salary: string;
  location: string;
  tags: string[];
};

const fallbackJobs: JobView[] = [
  {
    id: 1,
    title: "Nhân viên kinh doanh",
    company: "Công ty CP Du lịch Ninh Bình",
    salary: "10 - 18 triệu",
    location: "Ninh Bình",
    tags: ["Full-time", "1-2 năm", "Sales"],
  },
  {
    id: 2,
    title: "Kế toán tổng hợp",
    company: "Doanh nghiệp Xây dựng Hoa Lư",
    salary: "12 - 20 triệu",
    location: "Ninh Bình",
    tags: ["Onsite", "2+ năm", "Accounting"],
  },
  {
    id: 3,
    title: "Nhân viên marketing",
    company: "Tam Coc Travel Agency",
    salary: "9 - 16 triệu",
    location: "Ninh Bình",
    tags: ["Full-time", "Content", "Social"],
  },
];

export default function Home() {
  const categories = [
    "Kinh doanh / Bán hàng",
    "Marketing / Truyền thông",
    "Chăm sóc khách hàng",
    "Nhân sự / Hành chính",
    "Công nghệ thông tin",
    "Thiết kế sáng tạo",
    "Tài chính / Kế toán",
    "Vận hành / Logistics",
  ];

  const [jobs, setJobs] = useState<JobView[]>(fallbackJobs);
  const [statusText, setStatusText] = useState("");
  const { user, signOut } = useAuth();

  useEffect(() => {
    const loadJobs = async () => {
      if (!isSupabaseConfigured || !supabase) {
        setStatusText(
          "Chưa cấu hình Supabase. Đang hiển thị dữ liệu mẫu cho trang chủ."
        );
        return;
      }

      const { data, error } = await supabase
        .from("jobs")
        .select("id, title, company, salary, location, tags")
        .order("id", { ascending: false })
        .limit(6);

      if (error) {
        setStatusText(
          "Không tải được dữ liệu từ Supabase. Đang hiển thị dữ liệu mẫu."
        );
        return;
      }

      const records = (data ?? []) as JobRecord[];
      if (records.length === 0) {
        setStatusText("Supabase đã kết nối, nhưng bảng jobs chưa có dữ liệu.");
        return;
      }

      setJobs(
        records.map((job) => ({
          id: job.id,
          title: job.title,
          company: job.company,
          salary: job.salary,
          location: job.location,
          tags: Array.isArray(job.tags) ? job.tags : [],
        }))
      );
      setStatusText("Đã tải dữ liệu việc làm mới nhất từ Supabase.");
    };

    void loadJobs();
  }, []);

  return (
    <div className="home">
      <header className="navbar">
        <div className="logo">
          Tuyển dụng <span>Ninh Bình</span>
        </div>

        <nav className="nav-links">
          <a href="#">Việc làm</a>
          <a href="#">Nhà tuyển dụng</a>
          <a href="#">Công cụ</a>
          <a href="#">Cẩm nang</a>
        </nav>

        <div className="auth-buttons">
          {!user ? (
            <>
              <Link className="outline auth-link" to="/auth?mode=signup">
                Đăng ký
              </Link>
              <Link className="primary auth-link" to="/auth?mode=signin">
                Đăng nhập
              </Link>
            </>
          ) : (
            <>
              <span className="user-chip">{user.email}</span>
              <button className="outline" onClick={() => void signOut()}>
                Đăng xuất
              </button>
            </>
          )}
        </div>
      </header>

      <section className="hero">
        <div className="hero-main">
          <p className="hero-badge">Nền tảng việc làm tại địa phương</p>
          <h1>Tìm việc nhanh tại Ninh Bình, kết nối doanh nghiệp uy tín</h1>
          <p className="hero-description">
            Tổng hợp tin tuyển dụng mới nhất tại Ninh Bình, giúp ứng viên tiếp
            cận cơ hội phù hợp nhanh hơn.
          </p>

          <div className="search-bar">
            <input placeholder="Vị trí tuyển dụng, tên công ty..." />
            <input placeholder="Địa điểm làm việc" />
            <button>Tìm kiếm</button>
          </div>
        </div>

        <aside className="hero-panel">
          <h3>Chỉ số nổi bật</h3>
          <div className="metric-grid">
            <div>
              <strong>500+</strong>
              <span>Doanh nghiệp tại Ninh Bình</span>
            </div>
            <div>
              <strong>2.000+</strong>
              <span>Việc làm đang tuyển</span>
            </div>
            <div>
              <strong>92%</strong>
              <span>Hồ sơ được phản hồi</span>
            </div>
            <div>
              <strong>24/7</strong>
              <span>Hỗ trợ ứng viên và nhà tuyển dụng</span>
            </div>
          </div>
        </aside>
      </section>

      <section className="categories">
        <h2>Ngành nghề phổ biến tại Ninh Bình</h2>
        <div className="category-list">
          {categories.map((item) => (
            <button key={item} className="category-item">
              {item}
            </button>
          ))}
        </div>
      </section>

      <section className="job-section">
        <div className="job-heading">
          <h2>Việc làm nổi bật</h2>
          <a href="#">Xem tất cả</a>
        </div>

        {statusText && <p className="status-note">{statusText}</p>}

        <div className="job-grid">
          {jobs.map((job) => (
            <article key={job.id} className="job-card">
              <h3>{job.title}</h3>
              <p className="company">{job.company}</p>
              <div className="tags">
                <span>{job.salary}</span>
                <span>{job.location}</span>
              </div>
              <div className="skills">
                {job.tags.map((tag) => (
                  <small key={tag}>{tag}</small>
                ))}
              </div>
              <Link className="job-link" to={`/job/${job.id}`}>
                Xem chi tiết
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="cta">
        <h2>Sẵn sàng tìm việc tại Ninh Bình?</h2>
        <p>Tạo hồ sơ trong 3 phút và ứng tuyển ngay hôm nay.</p>
        <Link to="/post">
          <button>Đăng tin tuyển dụng</button>
        </Link>
      </section>
    </div>
  );
}
