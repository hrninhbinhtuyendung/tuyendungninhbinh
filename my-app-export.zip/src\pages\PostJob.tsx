﻿import { useState, type FormEvent } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { isSupabaseConfigured, supabase } from "../lib/supabase";

type JobForm = {
  title: string;
  company: string;
  salary: string;
  location: string;
  tags: string;
  description: string;
};

const defaultForm: JobForm = {
  title: "",
  company: "",
  salary: "",
  location: "Ninh Bình",
  tags: "",
  description: "",
};

function PostJob() {
  const { user } = useAuth();
  const [form, setForm] = useState<JobForm>(defaultForm);
  const [statusText, setStatusText] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!isSupabaseConfigured || !supabase) {
      setStatusText("Chưa cấu hình Supabase. Hãy thêm biến môi trường trước.");
      return;
    }

    if (!user) {
      setStatusText("Bạn cần đăng nhập trước khi đăng tin tuyển dụng.");
      return;
    }

    if (!form.title || !form.company || !form.salary || !form.location) {
      setStatusText("Vui lòng nhập đầy đủ thông tin bắt buộc.");
      return;
    }

    setSubmitting(true);
    setStatusText("Đang đăng tin...");

    const tags = form.tags
      .split(",")
      .map((tag) => tag.trim())
      .filter(Boolean);

    const { error } = await supabase.from("jobs").insert({
      title: form.title,
      company: form.company,
      salary: form.salary,
      location: form.location,
      tags,
      description: form.description || null,
    });

    if (error) {
      setStatusText(`Đăng tin thất bại: ${error.message}`);
      setSubmitting(false);
      return;
    }

    setStatusText("Đăng tin thành công.");
    setForm(defaultForm);
    setSubmitting(false);
  };

  return (
    <div>
      <h1>Đăng tuyển dụng</h1>
      <p>Nhập thông tin tin tuyển dụng để lưu vào Supabase.</p>
      {!user && (
        <p>
          Bạn chưa đăng nhập. <Link to="/auth?mode=signin">Đăng nhập ngay</Link>
        </p>
      )}

      <form
        onSubmit={onSubmit}
        style={{
          display: "grid",
          gap: "12px",
          maxWidth: "640px",
          marginTop: "16px",
        }}
      >
        <input
          placeholder="Tiêu đề việc làm *"
          value={form.title}
          onChange={(event) => setForm({ ...form, title: event.target.value })}
        />
        <input
          placeholder="Tên công ty *"
          value={form.company}
          onChange={(event) =>
            setForm({ ...form, company: event.target.value })
          }
        />
        <input
          placeholder="Mức lương *"
          value={form.salary}
          onChange={(event) => setForm({ ...form, salary: event.target.value })}
        />
        <input
          placeholder="Địa điểm *"
          value={form.location}
          onChange={(event) =>
            setForm({ ...form, location: event.target.value })
          }
        />
        <input
          placeholder="Tags, cách nhau bởi dấu phẩy"
          value={form.tags}
          onChange={(event) => setForm({ ...form, tags: event.target.value })}
        />
        <textarea
          placeholder="Mô tả công việc"
          rows={5}
          value={form.description}
          onChange={(event) =>
            setForm({ ...form, description: event.target.value })
          }
        />

        <button type="submit" disabled={submitting}>
          {submitting ? "Đang gửi..." : "Đăng tin"}
        </button>
      </form>

      {statusText && <p style={{ marginTop: "12px" }}>{statusText}</p>}
    </div>
  );
}

export default PostJob;
